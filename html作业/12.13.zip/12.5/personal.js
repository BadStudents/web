function coloregg() {
  document.getElementById("achieve")
  if (achieve.style.display=="none") {
    achieve.style.display="block";
  }
  else{
 achieve.style.display="none";
  }
}
function video() {
  document.getElementById("neymar").style.display="block";

}
