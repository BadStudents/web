function coloregg1() {
  document.getElementById("hotdog")
  if (hotdog.style.display=="none") {
    hotdog.style.display="block";
  }
  else{
 hotdog.style.display="none";
  }
}
function qqcode() {
  document.getElementById("qq").src="qqcode.jpg";
}
function wechatcode(){
  document.getElementById("wechat").src="wechatcode.jpg";
}